// Simple form submission message

const form = document.getElementById('contactForm');

const formMessage = document.getElementById('formMessage');

form.addEventListener('submit', function (e) {

  e.preventDefault();

  formMessage.textContent = "Thank you for your message! I will get back to you soon.";

  form.reset();

});